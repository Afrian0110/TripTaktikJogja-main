// detail-page.js

const detailPageApp = (() => {
  // Mapping elemen DOM
  const elements = {
    heroImage: document.getElementById('heroImage'),
    destinationTitle: document.getElementById('destinationTitle'),
    ratingScore: document.getElementById('ratingScore'),
    starsContainer: document.getElementById('starsContainer'),
    destinationLocation: document.getElementById('destinationLocation'),
    operatingHours: document.getElementById('operatingHours'),
    tourType: document.getElementById('tourType'),
    ticketPrice: document.getElementById('ticketPrice'),
    overviewText: document.getElementById('overviewText'),
    mapLocationName: document.getElementById('mapLocationName'),
    wishlistBtn: document.getElementById('toggleWishlistBtn'),
    wishlistIcon: document.getElementById('wishlist-icon'),
    wishlistText: document.getElementById('wishlist-text'),
  };

  let wisataData = null;

  function formatCurrency(amount) {
    return amount ? `Rp${amount.toLocaleString('id-ID')}` : '-';
  }

  function updateStars(rating) {
    const stars = elements.starsContainer.querySelectorAll('.star');
    stars.forEach((star, index) => {
      if (index < Math.round(rating)) {
        star.classList.remove('far');
        star.classList.add('fas'); // solid star
      } else {
        star.classList.remove('fas');
        star.classList.add('far'); // outline star
      }
    });
  }

  function renderData(data) {
    // Update judul dan gambar (default placeholder karena kamu belum punya gambar spesifik)
    elements.destinationTitle.textContent = data.nama;
    elements.heroImage.alt = data.nama;
    // Jika punya URL gambar bisa update src di sini:
    // elements.heroImage.src = data.imageUrl || '../images/placeholder-image.jpg';

    // Rating
    const ratingNum = parseFloat(data.vote_average.replace(',', '.'));
    elements.ratingScore.textContent = ratingNum.toFixed(1);
    updateStars(ratingNum);

    // Lokasi (latitude & longitude) - format jadi desimal dan tampilkan
    const lat = data.latitude.replace(',', '.');
    const lon = data.longitude.replace(',', '.');
    elements.destinationLocation.textContent = `Lat: ${lat}, Lon: ${lon}`;

    // Jam Operasional (ini contoh default karena data tidak ada, bisa disesuaikan)
    elements.operatingHours.textContent = '08.00 - 17.00 WIB';

    // Jenis tur
    elements.tourType.textContent = data.type || '-';

    // Harga tiket (ambil harga weekday)
    elements.ticketPrice.textContent = formatCurrency(data.htm_weekday);

    // Deskripsi
    elements.overviewText.textContent = data.description;

    // Map placeholder update nama lokasi
    elements.mapLocationName.textContent = data.nama;

    // Wishlist - cek apakah sudah di wishlist (contoh sederhana menggunakan localStorage 'wishlist')
    updateWishlistBtn();
  }

  function updateWishlistBtn() {
    const wishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
    const saved = wishlist.some(item => item.no === wisataData.no);
    if (saved) {
      elements.wishlistIcon.classList.remove('far');
      elements.wishlistIcon.classList.add('fas');
      elements.wishlistText.textContent = 'Sudah di Wishlist';
    } else {
      elements.wishlistIcon.classList.remove('fas');
      elements.wishlistIcon.classList.add('far');
      elements.wishlistText.textContent = 'Simpan ke Wishlist';
    }
  }

  function toggleWishlist() {
    let wishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
    const index = wishlist.findIndex(item => item.no === wisataData.no);
    if (index === -1) {
      // Tambah ke wishlist
      wishlist.push(wisataData);
      alert('Berhasil disimpan ke wishlist');
    } else {
      // Hapus dari wishlist
      wishlist.splice(index, 1);
      alert('Berhasil dihapus dari wishlist');
    }
    localStorage.setItem('wishlist', JSON.stringify(wishlist));
    updateWishlistBtn();
  }

  function logout() {
    alert('Logout clicked!');
    // Implementasi logout sesuai aplikasi kamu
  }

  function init() {
    // Ambil data wisata dari localStorage
    const stored = localStorage.getItem('selectedWisata');
    if (!stored) {
      alert('Data wisata tidak ditemukan, kembali ke halaman rekomendasi.');
      window.location.href = 'recommendation.html'; // sesuaikan path
      return;
    }
    wisataData = JSON.parse(stored);
    renderData(wisataData);

    elements.wishlistBtn.addEventListener('click', toggleWishlist);
  }

  return {
    init,
    logout,
  };
})();

// Inisialisasi saat halaman siap
document.addEventListener('DOMContentLoaded', detailPageApp.init);
