
// DOM selector yang sudah diperbaiki
const container = document.getElementById('recommendation-container');

// Load model
const model = await tf.loadLayersModel('../ml-model/model.json');

// Load data wisata dari file JSON
const response = await fetch('../data/data_wisata_with_vector.json');
const wisataList = await response.json();

// Simulasi vektor user (harusnya berdasarkan profil, minat, dsb)
const dummyUserVector = Array(100).fill(0.3); // ganti sesuai kebutuhan
const userInput = tf.tensor2d([dummyUserVector]);

// Filter berdasarkan skor dari model ML
const rekomendasi = [];

for (const wisata of wisataList) {
    // Asumsikan `wisata.vector` adalah array 100 angka
    if (!wisata.vector || wisata.vector.length !== 100) continue;

    const wisataInput = tf.tensor2d([wisata.vector]);

    // Prediksi kesamaan
    const scoreTensor = model.predict([userInput, wisataInput]);
    const score = await scoreTensor.data();
    const similarity = score[0];

    // Threshold bisa disesuaikan
    if (similarity >= 0.7) {
        rekomendasi.push(wisata);
    }
}

// Tampilkan hasil ke UI
window.homeSystem.renderWisataList(rekomendasi);
